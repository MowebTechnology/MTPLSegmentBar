//
//  MTPLSegmentBar.h
//  MTPLSegmentBar
//
//  Created by Ankit Patel on 07/02/20.
//  Copyright © 2020 Moweb. All rights reserved.
//

#import <Foundation/Foundation.h>

//! Project version number for MTPLSegmentBar.
FOUNDATION_EXPORT double MTPLSegmentBarVersionNumber;

//! Project version string for MTPLSegmentBar.
FOUNDATION_EXPORT const unsigned char MTPLSegmentBarVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <MTPLSegmentBar/PublicHeader.h>


